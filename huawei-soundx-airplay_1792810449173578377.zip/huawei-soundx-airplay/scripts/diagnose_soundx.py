#!/usr/bin/env python3
"""
华为 Sound X AirPlay 桥 —— 端到端诊断脚本

在任意能访问局域网的机器上运行（Mac / Linux / 旁路由本身均可，Python 3 即可）:

    python3 diagnose_soundx.py <SoundX_IP> [旁路由IP]

它会用"二分探测"定位断点，而不是让人盲改参数。核心思路:
  每一环都独立验证, 哪一环断了就是哪一环的问题。

输出解读见 references/troubleshooting.md
"""
import re
import sys
import time
import urllib.error
import urllib.request

SX_IP = sys.argv[1] if len(sys.argv) > 1 else "192.168.31.134"
GW_IP = sys.argv[2] if len(sys.argv) > 2 else "192.168.31.7"
STREAM_PORT = 8000

OK, BAD = "  ✓", "  ✗"
issues = []


def hdr(t):
    print(f"\n{'=' * 62}\n {t}\n{'=' * 62}")


def http_get(url, timeout=6, max_bytes=None):
    """max_bytes: 只读前 N 字节就返回(实时流如 FLAC 永不结束, 必须限量读)"""
    try:
        with urllib.request.urlopen(url, timeout=timeout) as r:
            data = r.read(max_bytes) if max_bytes else r.read()
            return r.status, data
    except urllib.error.HTTPError as e:
        return e.code, e.read()
    except Exception as e:
        return None, str(e).encode()


def soap(port, ctrl, action, args="", service="AVTransport"):
    url = f"http://{SX_IP}:{port}/upnp/control/{ctrl}"
    body = (
        '<?xml version="1.0"?><s:Envelope '
        'xmlns:s="http://schemas.xmlsoap.org/soap/envelope/" '
        's:encodingStyle="http://schemas.xmlsoap.org/soap/encoding/"><s:Body>'
        f'<u:{action} xmlns:u="urn:schemas-upnp-org:service:{service}:1">'
        f"<InstanceID>0</InstanceID>{args}</u:{action}></s:Body></s:Envelope>"
    )
    req = urllib.request.Request(url, data=body.encode(), headers={
        "Content-Type": 'text/xml; charset="utf-8"',
        "SOAPACTION": f'"urn:schemas-upnp-org:service:{service}:1#{action}"',
    })
    try:
        with urllib.request.urlopen(req, timeout=6) as r:
            return r.status, r.read().decode(errors="replace")
    except urllib.error.HTTPError as e:
        return e.code, e.read().decode(errors="replace")
    except Exception as e:
        return None, str(e)


def tag(xml, name):
    m = re.search(rf"<{name}>([^<]*)", xml or "")
    return m.group(1) if m else ""


# ---------------------------------------------------------------- 1. 发现端口
hdr("步骤 1 / 5  发现 Sound X 的 UPnP 控制端口（SSDP）")
print("广播 M-SEARCH 找 MediaRenderer…")
sx_port = None
try:
    import socket
    msg = ("M-SEARCH * HTTP/1.1\r\nHOST: 239.255.255.250:1900\r\n"
           'MAN: "ssdp:discover"\r\nMX: 2\r\n'
           "ST: urn:schemas-upnp-org:device:MediaRenderer:1\r\n\r\n")
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM, socket.IPPROTO_UDP)
    s.setsockopt(socket.IPPROTO_IP, socket.IP_MULTICAST_TTL, 4)
    s.settimeout(4)
    s.sendto(msg.encode(), ("239.255.255.250", 1900))
    t_end = time.time() + 4
    while time.time() < t_end:
        try:
            data, _ = s.recvfrom(65535)
        except socket.timeout:
            break
        txt = data.decode(errors="replace")
        if SX_IP in txt:
            m = re.search(r"LOCATION:\s*http://[\d.]+:(\d+)/", txt)
            if m:
                sx_port = int(m.group(1))
                print(f"{OK} SSDP 发现: {SX_IP}:{sx_port}")
                break
    s.close()
except Exception as e:
    print(f"  ! SSDP 失败({e}), 改用端口扫描")

if not sx_port:
    print("  SSDP 未发现, 扫描常见端口 49150-49270 + 其它…")
    import socket
    for p in list(range(49150, 49271)) + [8200, 1400, 8008, 8080, 8443, 8888]:
        try:
            c = socket.create_connection((SX_IP, p), timeout=0.4)
            c.close()
            st, body = http_get(f"http://{SX_IP}:{p}/description.xml", max_bytes=8192)
            if st == 200 and b"MediaRenderer" in body:
                sx_port = p
                print(f"{OK} 扫描发现: {SX_IP}:{p}")
                break
        except Exception:
            pass
    if not sx_port:
        print(f"{BAD} 未找到 UPnP 端口")
        print("   → 检查: 华为「智慧生活」App → Sound X → 音频投放/DLNA 开关是否打开")
        issues.append("Sound X 未暴露 UPnP/DLNA 服务(检查 App 里的 DLNA 开关)")

if not sx_port:
    sys.exit(1)

# ---------------------------------------------------------------- 2. 渲染器能力
hdr("步骤 2 / 5  验证 Sound X 渲染器能力")
st, xml = soap(sx_port, "rendertransport1", "GetProtocolInfo")
print(f"  GetProtocolInfo HTTP={st}")
st2, scpd = http_get(f"http://{SX_IP}:{sx_port}/rendertransportSCPD.xml")
acts = sorted(set(re.findall(r"<name>([^<]*)</name>", scpd.decode(errors="replace"))))
need = {"SetAVTransportURI", "Play", "Stop"}
have = need & set(acts)
if have == need:
    print(f"{OK} AVTransport 支持 {sorted(have)}")
else:
    print(f"{BAD} AVTransport 缺少 {sorted(need - have)}")
    issues.append(f"Sound X 缺少必要的 AVTransport 动作: {sorted(need - have)}")

st3, rc = http_get(f"http://{SX_IP}:{sx_port}/rendercontrolSCPD.xml")
racts = set(re.findall(r"<name>([^<]*)</name>", rc.decode(errors="replace")))
if "SetVolume" in racts:
    print(f"{OK} RenderingControl 支持 SetVolume(手机音量映射可用)")
else:
    print(f"{BAD} RenderingControl 无 SetVolume → 手机音量无法映射到硬件音量")

# ---------------------------------------------------------------- 3. 端到端二分
hdr("步骤 3 / 5  端到端二分探测（定位断点）")

# 3a. 渲染器控制是否可用
st, _ = soap(sx_port, "rendercontrol1", "SetVolume",
             "<Channel>Master</Channel><DesiredVolume>25</DesiredVolume>",
             service="RenderingControl")
if st == 200:
    print(f"{OK} 渲染器控制正常(SetVolume HTTP=200)")
    print("   → 音箱此刻应当有反馈音。若没有, 说明是音箱自身音量/静音问题")
else:
    print(f"{BAD} 渲染器控制失败 HTTP={st}")
    issues.append("无法控制 Sound X(检查防火墙/渲染器是否接受 UPnP)")

# 3b. bridge 的流接口（FLAC 是实时流, 只读前 4KB 判断, 否则会等超时)
st, body = http_get(f"http://{GW_IP}:{STREAM_PORT}/stream.flac", timeout=8, max_bytes=4096)
if st == 200 and body[:4] == b"fLaC":
    print(f"{OK} bridge 流接口正常(HTTP=200, FLAC 魔数正确)")
    print("   → shairport → 管道 → bridge 这一段是通的")
    if len(body) < 2000:
        print("   ! 但数据量偏少, 可能当前没有 AirPlay 会话在推流")
else:
    print(f"{BAD} bridge 流接口异常 HTTP={st}")
    print("   → shairport/bridge 进程可能没起来, 或端口/路径不对")
    issues.append(f"bridge 流接口异常 (HTTP={st}) 检查 8000 端口与 bridge 进程")

# 3c. 渲染器当前是否在播
st, xml = soap(sx_port, "rendertransport1", "GetTransportInfo")
state = tag(xml, "CurrentTransportState")
st, xml = soap(sx_port, "rendertransport1", "GetPositionInfo")
rel = tag(xml, "RelTime")
title = tag(xml, "dc:title")
print(f"  Sound X 状态: {state}  进度: {rel}  曲目: {title}")
if state == "PLAYING":
    print(f"{OK} 渲染器正在播放")
else:
    print(f"{BAD} 渲染器未在播放 → Play 指令没送达")
    issues.append("Sound X 处于 STOPPED, 说明 bridge 的 Play 指令没送达(检查 RENDERER_PORT)")

# ---------------------------------------------------------------- 4. 定位 RENDERER_PORT
hdr("步骤 4 / 5  定位 server.py 里必须配置的 RENDERER_PORT")
print(f"  Sound X 实际端口 = {sx_port}")
print(f"  server.py 原版写死 49152 → 必须改为 {sx_port}, 否则所有指令 Connection refused")
print()
print("  检查旁路由上的 server.py 是否已打补丁:")
print(f"    ssh root@{GW_IP} 'grep -n RENDERER_PORT /root/airplay2-dlna-bridge/bridge/server.py'")
print("  若无输出, 执行:")
print("    python3 - <<'EOF'")
print("    p='/root/airplay2-dlna-bridge/bridge/server.py'")
print("    s=open(p).read()")
print("    a='RENDERER_IP = os.environ.get(\"RENDERER_IP\") or os.environ.get(\"WIIM_IP\", \"\")'")
print("    if 'RENDERER_PORT' not in s:")
print("        s=s.replace(a, a+'\\nRENDERER_PORT = int(os.environ.get(\"RENDERER_PORT\", \"49152\"))')")
print("    s=s.replace('{self.ip}:49152','{self.ip}:{RENDERER_PORT}')")
print("    open(p,'w').write(s)")
print("    EOF")
print()
print(f"  然后把 init 脚本里的 RENDERER_PORT 改成 {sx_port} 并重启:")
print(f"    sed -i 's/RENDERER_PORT=[0-9]*/RENDERER_PORT={sx_port}/' /etc/init.d/airplay2-stack")
print(f"    /etc/init.d/airplay2-stack restart")

# ---------------------------------------------------------------- 5. 结论
hdr("步骤 5 / 5  结论")
if issues:
    print("发现以下问题(按优先级):\n")
    for i, s in enumerate(issues, 1):
        print(f"  {i}. {s}")
    print("\n详见 references/troubleshooting.md 对应章节")
    sys.exit(1)
else:
    print(f"{OK} 所有环节正常, 桥应该工作正常。")
    print("\n若仍无声音, 重点排查:")
    print("  a) iPhone 隔空投送列表里能否看到 'Sound X (AirPlay)'")
    print("     (看不到 → 查旁路由上 shairport-sync 是否活着、7000 端口是否监听)")
    print("  b) 手机调音量时 Sound X 有无反馈音")
    print("     (无反馈音 → 渲染器控制链路断, 即 RENDERER_PORT 不对)")
    print("  c) /tmp/bridge.log 里是否出现 'renderer AVTransport: http://<IP>:<port>/...'")
    print("     (没出现 → bridge 连不上渲染器, 即 RENDERER_PORT 不对)")
    print("  d) /tmp/bridge.log 里是否出现 'flac client ... connected'")
    print("     (没出现 → Sound X 没来取流, 检查音箱网络与防火墙)")
