#!/bin/sh
# =============================================================================
# 华为 Sound X AirPlay 桥 —— 一键部署脚本（在斐讯 N1 / iStoreOS 旁路由上运行）
#
# 用法（在旁路由的 SSH 里执行）:
#   sh deploy_soundx_airplay.sh <SoundX_IP> <旁路由IP>
#   例: sh deploy_soundx_airplay.sh 192.168.31.134 192.168.31.7
#
# 环境要求: iStoreOS/OpenWrt 24.10, aarch64, 已装 python3 + ffmpeg
#
# 设计要点（每一条都是踩过坑换来的，勿随意改动）:
#   1. 配置放私有路径, 不用 /etc/shairport-sync.conf
#      -> opkg 包自带的 init 脚本会按 UCI 重写该文件, 覆盖掉 pipe 后端
#   2. FIFO 管道"只建不删"
#      -> shairport-sync 与 bridge 都按"路径"重开管道, 删除重建会导致两端
#         拿到不同 inode, PCM 与 metadata 双双失联(表现为无声且音量无反馈)
#   3. 不用 pkill 杀进程
#      -> iStoreOS 上 pkill 可能静默失效(错误被 2>/dev/null 吞掉), 改用
#         ps | grep | awk 取 PID 后 kill -9
#   4. 不用 rc.common 的 shebang
#      -> rc.common 走 start_service 钩子, 脚本里自定义的 start() 不会被调用
#   5. 渲染器控制端口必须可配置
#      -> server.py 原版写死 49152, 而 Sound X 实际是 49494(或其他动态端口)
#   6. AirPlay 端口在 N1 上是 7000 不是 5000
#      -> 5000 从不监听但 AirPlay 正常, 别当故障指标
# =============================================================================

set -e

SX_IP="${1:?用法: sh deploy_soundx_airplay.sh <SoundX_IP> <旁路由IP>}"
GW_IP="${2:?用法: sh deploy_soundx_airplay.sh <SoundX_IP> <旁路由IP>}"

BASE=/root/airplay2-dlna-bridge
CONF="$BASE/shairport-sync.conf"
STREAM_PORT=8000

echo "=========================================="
echo " 华为 Sound X → AirPlay 桥 部署"
echo "   Sound X  : $SX_IP"
echo "   桥主机   : $GW_IP"
echo "=========================================="

# ---------- 1. 环境检查 ----------
echo "[1/7] 检查依赖..."
command -v python3 >/dev/null || { echo "  ✗ 缺 python3: opkg install python3"; exit 1; }
command -v ffmpeg  >/dev/null || { echo "  ✗ 缺 ffmpeg : opkg install ffmpeg"; exit 1; }
command -v shairport-sync >/dev/null || {
  echo "  ✗ 缺 shairport-sync: opkg install shairport-sync-mbedtls"; exit 1; }
echo "  ✓ python3 / ffmpeg / shairport-sync 就绪"

# ---------- 2. 停掉包自带服务 ----------
echo "[2/7] 停用 opkg 包自带的 shairport-sync 服务..."
# 必须停: 它会重写 /etc/shairport-sync.conf, 且会抢 7000 端口
/etc/init.d/shairport-sync stop 2>/dev/null || true
/etc/init.d/shairport-sync disable 2>/dev/null || true
echo "  ✓ 已停用（开机也不再自启）"

# ---------- 3. 获取 bridge 源码 ----------
echo "[3/7] 准备 bridge 源码..."
if [ ! -f "$BASE/bridge/server.py" ]; then
  mkdir -p "$BASE"
  cd "$BASE"
  if command -v git >/dev/null; then
    git clone --depth 1 https://github.com/shinn-y/airplay2-dlna-bridge.git \
      "$BASE" 2>/dev/null || {
      echo "  ✗ git clone 失败。若旁路由无法访问 GitHub, 请手动下载仓库后"
      echo "    把 bridge/server.py 放到 $BASE/bridge/server.py 再重跑本脚本"; exit 1; }
  else
    echo "  ✗ 无 git。请手动下载 https://github.com/shinn-y/airplay2-dlna-bridge"
    echo "    把 bridge/server.py 放到 $BASE/bridge/server.py 再重跑本脚本"; exit 1
  fi
else
  echo "  ✓ 已存在，跳过"
fi

# ---------- 4. 给 server.py 打渲染器端口补丁 ----------
echo "[4/7] 给 server.py 打渲染器端口补丁（幂等）..."
python3 - <<PYEOF
import re, shutil
p = "$BASE/bridge/server.py"
s = open(p).read()
if "RENDERER_PORT" not in s:
    shutil.copy(p, p + ".orig")
    anchor = 'RENDERER_IP = os.environ.get("RENDERER_IP") or os.environ.get("WIIM_IP", "")'
    if anchor in s:
        s = s.replace(anchor, anchor +
            '\nRENDERER_PORT = int(os.environ.get("RENDERER_PORT", "49152"))')
    s = s.replace("{self.ip}:49152", "{self.ip}:{RENDERER_PORT}")
    open(p, "w").write(s)
    print("  ✓ 已注入 RENDERER_PORT")
else:
    print("  ✓ 已有 RENDERER_PORT，跳过")
PYEOF

# ---------- 5. 写私有 shairport 配置 ----------
echo "[5/7] 写私有 shairport 配置（不碰 /etc/shairport-sync.conf）..."
mkdir -p "$BASE"
cat > "$CONF" <<EOF
general =
{
	name = "Sound X (AirPlay)";
	output_backend = "pipe";
	ignore_volume_control = "yes";
};

pipe =
{
	name = "/shared/audio";
	output_rate = 44100;
	output_format = "S16_LE";
	output_channels = 2;
};

metadata =
{
	enabled = "yes";
	include_cover_art = "yes";
	pipe_name = "/shared/metadata";
};

sessioncontrol =
{
	session_timeout = 60;
};
EOF
echo "  ✓ 已写入 $CONF"

# ---------- 6. 写 init 脚本 ----------
echo "[6/7] 写 init 脚本 + 开机自启..."
cat > /etc/init.d/airplay2-stack <<EOF
#!/bin/sh

CONF=$CONF
BRIDGE=$BASE/bridge/server.py

# 用 ps|grep|awk 取 PID 精确 kill, 不用 pkill(iStoreOS 上 pkill 会静默失效)
kill_ours() {
    for p in \$(ps w | grep -v grep | grep -E "airplay2-dlna-bridge/bridge/server\\.py|bin/shairport-sync" | awk '{print \$1}'); do
        kill -9 "\$p" 2>/dev/null
    done
}

do_start() {
    kill_ours
    sleep 1
    # 关键: FIFO 只建不删! 删除重建会让两端按路径重开时拿到不同 inode,
    # 导致 PCM 和 metadata 双双失联(无声 + 手机调音量无反馈音)
    mkdir -p /shared
    [ -p /shared/audio ] || mkfifo /shared/audio
    [ -p /shared/metadata ] || mkfifo /shared/metadata
    chmod 666 /shared/audio /shared/metadata 2>/dev/null

    # 先起 bridge(管道读端)
    STREAM_PORT=$STREAM_PORT \\
    STREAM_URL=http://$GW_IP:$STREAM_PORT/stream.flac \\
    RENDERER_IP=$SX_IP \\
    RENDERER_PORT=\${RENDERER_PORT:-49494} \\
    MAX_VOLUME=100 \\
    DIDL_PUSH=1 \\
    FLUSH_RESYNC=0 \\
    /usr/bin/python3 "\$BRIDGE" >/tmp/bridge.log 2>&1 &
    sleep 2
    # 再起 shairport(管道写端)
    /usr/bin/shairport-sync -c "\$CONF" >/tmp/shairport.log 2>&1 &
    sleep 2
}

do_stop() {
    kill_ours
}

case "\$1" in
    start|restart) do_start ;;
    stop)          do_stop ;;
    enable)  ln -sf /etc/init.d/airplay2-stack /etc/rc.d/S99airplay2-stack; echo enabled ;;
    disable) rm -f /etc/rc.d/S99airplay2-stack; echo disabled ;;
    status)  ps w | grep -E "shairport|server\\.py" | grep -v grep
             netstat -tlnp 2>/dev/null | grep -E ":7000|:8000" ;;
    *) echo "usage: \$0 {start|stop|restart|enable|disable|status}"; exit 1 ;;
esac
EOF
chmod +x /etc/init.d/airplay2-stack

# 开机自启: rc.d 软链。同时清掉 rc.local 里的重复调用(否则开机跑两遍互杀)
/etc/init.d/airplay2-stack enable
sed -i '/airplay2-stack/d' /etc/rc.local 2>/dev/null || true
echo "  ✓ 已写入并启用开机自启"

# ---------- 7. 启动 + 自检 ----------
echo "[7/7] 启动服务并自检..."
/etc/init.d/airplay2-stack start
sleep 4

echo
echo "----- 进程 -----"
ps w | grep -E "shairport|server\.py" | grep -v grep || echo "  (无进程!)"
echo "----- 端口 (7000=AirPlay, 8000=bridge) -----"
netstat -tlnp 2>/dev/null | grep -E ":7000|:8000" || echo "  (未监听!)"
echo "----- bridge.log -----"
cat /tmp/bridge.log 2>/dev/null || echo "  (无日志)"
echo "----- shairport.log -----"
cat /tmp/shairport.log 2>/dev/null || echo "  (无日志)"
echo
echo "=========================================="
echo " 部署完成"
echo "=========================================="
echo "1) iPhone 隔空投送列表应出现 \"Sound X (AirPlay)\""
echo "2) 若 Sound X 实际端口不是 49494, 先跑诊断:"
echo "     sh diagnose_soundx.sh $SX_IP"
echo "   把输出里的真实端口填回 /etc/init.d/airplay2-stack 的 RENDERER_PORT"
echo "3) 详见 diagnose_soundx.sh 的输出解读"
