---
name: huawei-soundx-airplay
description: 让华为 Sound X（及其他支持 DLNA 的华为音箱）支持 AirPlay 投歌。在斐讯 N1 / iStoreOS / OpenWrt 旁路由上部署「AirPlay 2 接收端 + DLNA 转发桥」，让 iPhone/Mac 的隔空投送能直接选到音箱。包含一键部署脚本、端到端诊断脚本，以及一份踩坑手册（症状索引 → 根因 → 解法）。当用户希望 Sound X / 华为音箱支持 AirPlay、把 AirPlay 投到华为音箱、用旁路由给音箱做 AirPlay 桥、或排查这类桥接"没声音"故障时使用。
agent_created: true
---

# 华为 Sound X AirPlay 桥

在旁路由（斐讯 N1 / iStoreOS / OpenWrt）上搭建「AirPlay 2 接收 → DLNA 转发」桥，
让 iPhone / Mac 的隔空投送能直接选到华为 Sound X 播放。

## 核心架构

```
iPhone --AirPlay2--> shairport-sync --PCM FIFO--> bridge --FLAC/HTTP--> Sound X (DLNA)
                                        (歌名/音量也走 metadata FIFO)
```

- **shairport-sync**：接收 AirPlay 2，输出 PCM 到命名管道（`output_backend = "pipe"`）
- **bridge**（`shinn-y/airplay2-dlna-bridge` 的 `bridge/server.py`）：读 PCM → ffmpeg 编码 FLAC → HTTP :8000；同时读 metadata 管道，用 UPnP 命令 Sound X 播放 / 调音量 / 推歌名封面
- **Sound X**：华为的 DLNA 渲染器，主动来拉 bridge 的 HTTP 流

**关键理解**：这是**双向**链路。音频方向（Sound X 拉流）和控制方向（bridge 用 UPnP 指挥 Sound X）必须**都通**才有声音。
排查时最常见的误判是只查音频方向，而真正断在控制方向。

## 执行流程

### 阶段 1：确认环境
在旁路由 SSH 上执行：
```sh
cat /etc/openwrt_release     # iStoreOS / OpenWrt 24.10
uname -m                     # aarch64
df -h / | tail -1            # 需 >=1GB 空闲
opkg list 2>/dev/null | grep -i shairport   # 应有 shairport-sync 4.x
```

**必须先开启 Sound X 的 DLNA**：华为「智慧生活」App → 设备 → Sound X → **音频投放 / DLNA** 开关打开。
关着时音箱不对外暴露 UPnP 服务，端口扫描会全部失败。

### 阶段 2：部署
把 `scripts/deploy_soundx_airplay.sh` 传到旁路由执行：
```sh
sh deploy_soundx_airplay.sh <SoundX_IP> <旁路由IP>
# 例: sh deploy_soundx_airplay.sh 192.168.31.134 192.168.31.7
```
脚本会：检查依赖 → 停用 opkg 包自带服务 → 拉 bridge 源码 → 给 server.py 打 RENDERER_PORT 补丁 →
写私有配置 → 写 init 脚本并启用开机自启 → 启动并打印自检结果。

### 阶段 3：验证
1. iPhone 隔空投送列表应出现 **"Sound X (AirPlay)"**
2. 投歌后 Sound X 应出声
3. 手机调音量时 Sound X 应有**反馈音**（这是控制链路活的标志）

### 阶段 4：诊断（出问题必做）
```sh
python3 scripts/diagnose_soundx.py <SoundX_IP> [旁路由IP]
```
该脚本用**二分探测**逐环验证并直接指出断点：
SSDP 发现渲染器端口 → 验证 SetAVTransportURI/Play/SetVolume 是否支持 →
探测渲染器控制是否通 → 探测 bridge 流接口 → 查渲染器是否在播 → 给出 RENDERER_PORT 修正命令。

**在能访问局域网的机器上运行**（Mac/PC 均可），比 SSH 到旁路由上看日志高效得多。

## 六个不可违背的设计约束

这些是实际踩坑换来的，**任何一条被破坏都会导致"无声"**，详见 `references/troubleshooting.md` §2。

1. **配置放私有路径** `/root/airplay2-dlna-bridge/shairport-sync.conf`，不用 `/etc/shairport-sync.conf`
   （opkg 包自带 init 脚本会按 UCI 重写后者，把 pipe 后端覆盖成 alsa → N1 无声卡 → 进程 fatal 退出）
2. **FIFO 只建不删**：`[ -p /shared/audio ] || mkfifo /shared/audio`
   （两端都按路径重开管道，删重建会让它们拿到不同 inode → PCM 与 metadata 双失联）
3. **不用 `pkill`**：iStoreOS 上会静默失效，改用 `ps|grep|awk` 取 PID 后 `kill -9`
4. **不用 `#!/bin/sh /etc/rc.common`**：rc.common 走 `start_service` 钩子，自定义 `start()` 不被调用 → 改纯 shell + 手动 `case` 分发
5. **渲染器端口必须可配置**：server.py 原版写死 49152，Sound X 实际是 49494 → 必须打 `RENDERER_PORT` 补丁
6. **AirPlay 端口是 7000 不是 5000**（N1 上如此）→ 别把"没有 5000"当故障

## 故障排查

**先查 `references/troubleshooting.md` 的 §1 症状索引表**，它把「症状 → 根因 → 解法」一一对应。

最灵敏的指示器：**手机调音量时 Sound X 有无反馈音**。
该反馈音由 bridge 成功送达 `SetVolume` 产生——它消失就说明**控制链路已死**，此时再去查音频方向是浪费时间。

排查顺序建议：
1. 先跑 `diagnose_soundx.py` 定位断点
2. 再看旁路由 `/tmp/bridge.log` 与 `/tmp/shairport.log`
   - 必须出现 `renderer AVTransport: http://<IP>:<port>/...`（渲染器已连上）
   - `flac client ... connected`（Sound X 来取流了）
   - `renderer: play (歌名 - 歌手)`（Play 已送达）
3. 确认旁路由的 `bridge.log` 无 `Address in use`、`shairport.log` 无 `port 7000` 冲突（说明有旧实例残留）

## 延迟调优

当前约 9~10 秒。安全旋钮与危险旋钮见 `references/troubleshooting.md` §4。

**铁律：一次只改一个参数，改完立刻实测。** 两个同时改，一旦失声无法分辨是哪个引起。

| 参数 | 位置 | 默认 | 建议 | 备注 |
|------|------|------|------|------|
| `PUSH_SETTLE` | server.py | 2.0 | 0.5 | 省 ~1.5s，极低风险 |
| `CLIENT_BACKLOG` | server.py | 256*1024 | 96*1024 | 省 ~1s，**太小会预缓冲不足卡住** |
| `DIDL_PUSH` | init 脚本 env | 1 | 0 | 每首省 2~4s，**代价：音箱不刷新歌名/封面** |
| `MAX_VOLUME` | init 脚本 env | 100 | 按需 | 手机满格对应的音箱音量上限（保护耳朵） |

**禁止修改** `audio_backend_latency_offset_in_seconds`（pipe 后端下会让音频写不进 FIFO，直接导致完全无声）。

## 已知限制

- 端到端延迟理论下限约 5~6 秒（Sound X 自身有 2~3s HTTP 缓冲，无法从桥侧消除），**不适合看视频**（会口型不同步）
- AirPlay 2 依赖 nqptp 做时钟同步；若软件源无 nqptp，shairport-sync 会以 AirPlay 1 模式工作，投歌仍可用
- 不同华为音箱型号的 UPnP 端口可能不同，**必须现场 SSDP 扫描确认**，不要假设是 49494

## 资源

- `scripts/deploy_soundx_airplay.sh` —— 一键部署（含幂等补丁、init 脚本、开机自启）
- `scripts/diagnose_soundx.py` —— 端到端二分诊断，输出断点与修复命令
- `references/troubleshooting.md` —— 踩坑手册：症状索引表、6 条设计约束、延迟调优、指示器速查
