# 华为 Sound X AirPlay 桥 —— 故障排查手册

> 本文档记录的都是实际踩过的坑。**遇到"没声音"类问题，先看第 1 节的症状索引表**，能省下大量盲目试参数的时间。

---

## 0. 架构与数据流

```
iPhone / Mac
   │  AirPlay 2 (RTP + nqptp 时钟同步)
   ▼
shairport-sync  ── 接收 AirPlay, 解码为 PCM
   │  output_backend = "pipe"  →  写 FIFO
   ▼
/shared/audio  (FIFO, 44100Hz/S16_LE/2ch)      ← ★ 断点高发区
   │
   ▼
bridge (server.py)  ── 读 PCM → 环形缓冲 → ffmpeg 编码 FLAC → HTTP :8000
   │                    ↑ 同时读 /shared/metadata (FIFO) 拿歌名/音量
   │
   │  ① HTTP GET /stream.flac  ← Sound X 主动来拉流
   │  ② UPnP SetAVTransportURI + Play + SetVolume  ← bridge 主动指挥
   ▼
Sound X  (DLNA 渲染器, UPnP 控制端口 **49494**)
```

**两个方向的数据流都必须通**：
- **① 音频方向**：Sound X → 拉 bridge 的 HTTP 流 → 出声
- **② 控制方向**：bridge → UPnP 命令 → Sound X 开始播 / 调音量

**最容易漏判的是方向 ②**。音频流好好的在跑、渲染器却一声不吭，根因几乎总是"Play 指令没送达"。

---

## 1. 症状索引表（先查这里）

| 症状 | 最可能的根因 | 跳到 |
|------|-------------|------|
| **隔空投送列表里看不到设备** | shairport-sync 没活着 / 没绑 7000 | §3.1 |
| **能看到设备、进度条在走，但音箱完全没声** | bridge 的 Play 指令没送达（RENDERER_PORT 不对） | §3.2 |
| **没声，且手机调音量时音箱也没反馈音** | 同上（控制链路断）—— **这是最强的指示器** | §3.2 |
| **没声，但手机调音量有反馈音** | 音频方向断：FIFO inode 失联 | §3.3 |
| **切歌时每首都多等好几秒** | DIDL_PUSH 重推流导致播放器重开流 | §4.2 |
| **音箱显示"播放中"但没声音** | 渲染器在拉流但解不出 / 缓冲区不足 | §3.4 |
| **N1 重启后整个失效** | init 脚本没启用 / 配置被包覆盖 | §3.5 |

---

## 2. 部署期必知（6 个设计约束）

这 6 条都是踩坑换来的，**每一条都对应一个"看起来毫不相关的症状"**。

### 2.1 配置放私有路径，别用 `/etc/shairport-sync.conf`
opkg 装的 `shairport-sync` **自带 init 脚本**，它会按 UCI `/etc/config/shairport-sync` **重新生成** `/etc/shairport-sync.conf`。
后果：我们的 `output_backend = "pipe"` 被覆盖成 `alsa` → N1 无声卡 → `fatal error: output_device_error_2` → 进程退出。

**解法**：配置写到 `/root/airplay2-dlna-bridge/shairport-sync.conf`，init 脚本用 `-c` 指向它；同时 `stop` + `disable` 包自带服务。

### 2.2 FIFO「只建不删」
shairport-sync 与 bridge **都按路径**打开 FIFO（shairport 每次 AirPlay 会话开始时重开、bridge 在管道断开后重开），**不是**永久持有 fd。

后果：`rm -f /shared/audio && mkfifo` 换掉 inode → 两端下次各自重开拿到**不同 inode** → PCM 与 metadata **双双失联**。

**解法**：`[ -p /shared/audio ] || mkfifo /shared/audio`（只在不存在时创建）。确需重建必须先 kill 掉两端进程。

> **这个坑的特征**：iPhone 进度条正常走、但音箱全哑，**且手机调音量时音箱也没有反馈音**——因为 metadata 管道也断了。

### 2.3 别用 `pkill`
iStoreOS 上 `pkill` 可能**静默失效**（错误被 `2>/dev/null` 吞掉），旧进程残留继续占端口，导致新实例报 `Address in use` / `could not establish a service on port 7000`，看起来像"配置不对"，实际是"旧的还在跑"。

**解法**：
```sh
for p in $(ps w | grep -v grep | grep -E "bridge/server\.py|bin/shairport-sync" | awk '{print $1}'); do
    kill -9 "$p" 2>/dev/null
done
```

### 2.4 别用 `#!/bin/sh /etc/rc.common`
该 shebang 下 rc.common 走的是 `start_service` 钩子，脚本里自定义的 `start()` / `stop()` **不会被调用**。表现为"执行了但毫无反应、日志文件都没生成"。

**解法**：写纯 shell 脚本 + 手动 `case "$1" in start|stop|restart|...)` 分发；`enable` 自己做 `ln -sf /etc/init.d/X /etc/rc.d/S99X`。

### 2.5 渲染器端口必须可配置
`server.py` 原版把渲染器控制端口**写死 49152**（DLNA 常见默认值），但 **Sound X 实际是 49494**（甚至可能是其他动态端口）。

后果：bridge 每条指令都 `Connection refused` → Play 发不出去 → 音箱 STOPPED、无声、**且手机调音量没有反馈音**。

**解法**：给 server.py 打幂等补丁：
```python
RENDERER_PORT = int(os.environ.get("RENDERER_PORT", "49152"))
# 并把 {self.ip}:49152 换成 {self.ip}:{RENDERER_PORT}
```
启动时传 `RENDERER_PORT=49494`。真实端口用 SSDP 扫（见 `scripts/diagnose_soundx.py`）。

### 2.6 AirPlay 端口是 7000，不是 5000
N1 上 shairport-sync 监听的是 **7000**，5000 从不监听——但 AirPlay 一切正常。**别把"没有 5000"当故障指标**，该看的是 7000 + 8000。

---

## 3. 深度排查

### 3.1 隔空投送列表里看不到设备
```sh
ps w | grep shairport | grep -v grep
netstat -tlnp 2>/dev/null | grep -E ":7000|:8000"
cat /tmp/shairport.log
```
- 进程不在 → init 脚本没跑起来，看 `/tmp/shairport.log`
- 进程在但没绑 7000 → 检查配置里的 `output_backend` 是否还是 `pipe`（见 §2.1）
- 报 `could not establish a service on port 7000` → **有旧实例占着**，用 §2.3 的方式精确 kill

### 3.2 进度条在走但音箱无声（且调音量无反馈音）★最常见
**这是控制链路断，不是音频链路断。**

快速判定（在能访问局域网的机器上）：
```sh
# 直接命令音箱改音量，返回 200 说明渲染器控制本身没问题
curl -s -o /dev/null -w "%{http_code}\n" \
  -H 'Content-Type: text/xml; charset="utf-8"' \
  -H 'SOAPACTION: "urn:schemas-upnp-org:service:RenderingControl:1#SetVolume"' \
  --data-binary '<?xml version="1.0"?><s:Envelope xmlns:s="http://schemas.xmlsoap.org/soap/envelope/" s:encodingStyle="http://schemas.xmlsoap.org/soap/encoding/"><s:Body><u:SetVolume xmlns:u="urn:schemas-upnp-org:service:RenderingControl:1"><InstanceID>0</InstanceID><Channel>Master</Channel><DesiredVolume>30</DesiredVolume></u:SetVolume></s:Body></s:Envelope>' \
  "http://<SoundX_IP>:49494/upnp/control/rendercontrol1"

# 看音箱到底在不在播
curl -s "http://<SoundX_IP>:49494/upnp/control/rendertransport1" \
  -H 'Content-Type: text/xml' -H 'SOAPACTION: "urn:schemas-upnp-org:service:AVTransport:1#GetTransportInfo"' \
  --data-binary '<?xml version="1.0"?><s:Envelope xmlns:s="http://schemas.xmlsoap.org/soap/envelope/" s:encodingStyle="http://schemas.xmlsoap.org/soap/encoding/"><s:Body><u:GetTransportInfo xmlns:u="urn:schemas-upnp-org:service:AVTransport:1"><InstanceID>0</InstanceID></u:GetTransportInfo></s:Body></s:Envelope>' | grep -oE "<CurrentTransportState>[^<]*"
```

- SetVolume 返回 200 但 GetTransportInfo 是 **STOPPED** → bridge 没送达 Play → **RENDERER_PORT 不对**（§2.5）
- 确认方式：看旁路由 `/tmp/bridge.log`，应该出现
  `renderer AVTransport: http://<IP>:49494/upnp/control/rendertransport1`
  **这行从未出现过 = 端口不对。**

### 3.3 音频方向断（FIFO inode 失联）
特征：调音量**有**反馈音（控制通），但就是没声（音频不通）。

```sh
# 对比：管道 inode 号 vs 两端进程持有的 fd inode 号，必须一致
ls -i /shared/audio
ls -l /proc/<bridge_pid>/fd | grep shared
ls -l /proc/<shairport_pid>/fd | grep shared
```
数字不等 → 失联。解法见 §2.2（只建不删 + 杀干净后一起重启）。

### 3.4 音箱显示"播放中"但没声
- 确认 Sound X 真的来取流了：旁路由 `/tmp/bridge.log` 里应有 `flac client ... connected`
- 没有这行 → Sound X 没连过来，检查音箱网络与防火墙
- 有这行但仍无声 → 可能是 Sound X 解不出 FLAC，或预缓冲不足
- **降延迟时若把 `CLIENT_BACKLOG` 调太小，会出现这种"卡住不出声"**（见 §4.1）

### 3.5 重启后失效
```sh
ls -l /etc/rc.d/ | grep airplay        # 软链在不在
grep -n "airplay2-stack" /etc/rc.local # 应为空(重复调用会开机跑两遍互杀)
grep -E "RENDERER_PORT|output_backend" /etc/init.d/airplay2-stack /root/airplay2-dlna-bridge/shairport-sync.conf
```

---

## 4. 延迟调优

### 4.1 安全旋钮（可调）
| 参数 | 位置 | 默认 | 建议 | 效果/风险 |
|------|------|------|------|----------|
| `PUSH_SETTLE` | server.py | 2.0 | 0.5 | 等元数据落地的静默期，↓ 省 ~1.5s；极低风险 |
| `CLIENT_BACKLOG` | server.py | 256*1024 | 96*1024 | 新客户端从活边缘往回取的量(≈1.5s→0.55s)，↓ 省 ~1s；**太小会预缓冲不足卡住** |
| `DIDL_PUSH` | init 脚本 env | 1 | 0 | 切歌不重推流，每首省 2~4s；**代价：音箱不刷新歌名/封面** |
| `MAX_VOLUME` | init 脚本 env | 100 | 按需 | 手机满格对应的音箱硬件音量上限（保护耳朵） |

**调优原则（重要）**：**一次只改一个参数**，改完立刻实测。原因：这两个参数一旦同时改，一旦失声就无法分辨是哪个引起——曾因此浪费大量时间。

### 4.2 危险旋钮（不要动）
| 参数 | 为什么危险 |
|------|-----------|
| `audio_backend_latency_offset_in_seconds` | 本是为 ALSA 等实时设备设计的；**pipe 后端下时序错乱，音频根本写不进 FIFO**。曾导致完全无声。 |
| `rm -f /shared/audio` | 见 §2.2，直接导致无声 |
| `shairport-sync` 的 ALSA 后端 | N1 无声卡，必 fatal |

### 4.3 延迟构成参考
```
总延迟 ≈ AirPlay 侧(1~2s) + PUSH_SETTLE(0.5~2s) + CLIENT_BACKLOG(0.5~1.5s)
        + Sound X 自身 HTTP 缓冲(2~3s) + FLAC 编码
```
**Sound X 自身那 2~3s 无法从桥侧消除**，所以理论下限约 5~6s。

---

## 5. 关键指示器速查

| 现象 | 说明什么 |
|------|---------|
| **手机调音量时 Sound X 有反馈音** | bridge→渲染器控制链路**通**（这条音就是 SetVolume 成功的产物）——**最灵敏的指示器** |
| **手机调音量时没有反馈音** | 控制链路已死，别再去查音频方向 |
| bridge.log 出现 `renderer AVTransport: http://IP:PORT/...` | 渲染器已连上（这行**必须出现**） |
| bridge.log 出现 `flac client ... connected` | Sound X 真的来取流了 |
| bridge.log 出现 `renderer: play (歌名 - 歌手)` | Play 指令已送达 |
| `ssdp` 扫到 `LOCATION: http://IP:49494/description.xml` | 拿到渲染器真实端口 |

---

## 6. 环境差异提示

不同用户的旁路由环境可能不同，需现场确认：

| 项 | 常见值 | 怎么确认 |
|----|--------|---------|
| 系统 | iStoreOS 24.10 / OpenWrt 24.10 | `cat /etc/openwrt_release` |
| 架构 | aarch64 (N1/玩客云等) | `uname -m` |
| 音频服务端口 | **7000**（非 5000） | `netstat -tlnp \| grep 7000` |
| 渲染器端口 | 49494（可能不同） | SSDP 扫或 `diagnose_soundx.py` |
| 包管理器 | opkg | `opkg list \| grep shairport` |
| 代理环境 | 中国网络需注意 | 拉 GitHub/Docker 需代理 |

**shairport-sync 变体选择**：装 `shairport-sync-mbedtls` 或 `-openssl`（完整版），**不要装 `-mini`**（精简版可能缺 metadata/封面支持）。
